module tp6 {
	requires java.desktop;
}