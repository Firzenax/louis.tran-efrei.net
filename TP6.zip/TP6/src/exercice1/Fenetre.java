package exercice1;

import javax.swing.*;
public class Fenetre{
	public void faire_apparaitre() {
		JFrame f = new JFrame("Ma Fen�tre");
		JLabel label = new JLabel("Bonjour");
		JPanel p = (JPanel)f.getContentPane();
		p.add(label);
		f.setSize(300,200);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
}
}
