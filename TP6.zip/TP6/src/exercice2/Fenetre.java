package exercice2;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Fenetre{
	private static JTextField Nom;
	public void faire_apparaitre() {
		Nom = new JTextField(10);
		
		JFrame f = new JFrame("Ma Fen�tre");
		JLabel label = new JLabel("Bonjour");
		label.setLayout(new FlowLayout());
		label.add(Nom);
		JPanel p = (JPanel)f.getContentPane();
		p.add(label);
		f.setSize(300,200);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
}
}
