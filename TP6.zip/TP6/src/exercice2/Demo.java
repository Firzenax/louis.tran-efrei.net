package exercice2;

public class Demo {

	public static void main (String[] args)
	{
		Fenetre f = new Fenetre();
		f.faire_apparaitre();
	}

}
