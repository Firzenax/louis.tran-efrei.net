import java.util.Arrays;

public class CloneArrayOfInt implements Cloneable{
    private int[] vector;

    public CloneArrayOfInt(int[] vector){
        this.vector = vector;
    }

    public int[] getVector() { return vector; }

    @Override
    public String toString() {
        return "CloneArrayOfInt{ vector=" + Arrays.toString(vector) + '}';
    }

    public Object clone(){
        Object objet = null;
        try{
            objet = super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return objet;
    }

}
