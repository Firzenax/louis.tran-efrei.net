public class Test {

    public static void main(String args[]){
        int[] vector = new int[]{1, 2, 3};
        CloneArrayOfInt array = new CloneArrayOfInt(vector);
        CloneArrayOfInt array1 = (CloneArrayOfInt)array.clone();
        CloneArrayOfInt array2 = (CloneArrayOfInt)array.clone();
        System.out.println(array.toString());
        System.out.println(array1.toString());
        System.out.println(array2.toString());
    }
}
