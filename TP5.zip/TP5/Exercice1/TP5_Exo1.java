
package tp5_exo1;

import java.util.function.BiFunction;
import java.util.function.Function;

public class TP5_Exo1 {


    public static void main(String[] args) {
        
        BiFunction<Integer, Integer, Double> fonction1 = (int1, int2) -> Math.pow(int1, int2);
        
        
        Function<Double, String> fonction2 = (input) -> "Result : " + String.valueOf(input);
        
        String resultat = fonction1.andThen(fonction2).apply(2, 4);
        
        System.out.println(resultat);
        
    }
    
}
