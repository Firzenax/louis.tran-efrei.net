
package tp5_exo1_2;

import java.util.function.BiFunction;
import java.util.function.Function;

public class TP5_Exo1_2 {

    public static void main(String[] args) {
       
        String resultat = puissance_chaine(2, 4,
                (int1, int2) -> Math.pow(int1, int2),
                (res) -> "Result : " + String.valueOf(res));
        
        System.out.println(resultat);
    }
    
    public static <R> R puissance_chaine(Integer int1, Integer int2,
            BiFunction<Integer, Integer, Double> fonction1,
            Function<Double, R> fonction2){
        
        return fonction1.andThen(fonction2).apply(int1, int2);
    }
    
}
