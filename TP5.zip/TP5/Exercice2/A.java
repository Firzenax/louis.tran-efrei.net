class A implements Cloneable{
    private int x;
    public A(int i) {
        x = i;
    }

    public int getX() { return x; }

    public Object clone(){
        Object o = null;
        try{
            o = super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return o;
    }

}
