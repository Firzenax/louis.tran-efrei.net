public class CloneTestA {
    public static void main(String[] args) throws CloneNotSupportedException {
        A obj1 = new A(37);
        A obj2 = (A)obj1.clone();
        if(obj1.clone().getClass() != obj2.getClass())
            throw new CloneNotSupportedException("Le clonage n'a pas pu être effectué");
        else{
            System.out.println(obj1.getX());
            System.out.println(obj2.getX());
        }
    }
}
