package Company;
class A implements
{
    private int x;
    public A(int i)
    {
        x = i;
    }
}
//Pour utiliser la méthode clone sur une instance d'une classe A,
// il est généralement nécessaire que la classe A redéfinisse la
// méthode clone de la classe Object. En effet, la méthode clone de la
// classe Object est protected ; cela implique qu'on ne peut l'invoquer que du paquetage java.
public class CloneTestA
{
    public static void main(String args[]) throws
            CloneNotSupportedException
    {
        A obj1 = new A(37);
        try{
            A obj2 = (A) obj1.clone();
        }
        catch (CloneNotSupportedException e)
        {
            e.printStackTrace();
        }
    }
}*/