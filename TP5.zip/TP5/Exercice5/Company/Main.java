package Company;

import Chaine_TV.*;

import java.io.IOException;

public class Main {

    public static void main(String[] args){
        Chaine ch = new Chaine(1,"TF1",103.98f,true);
        System.out.println(ch.toString());
        Chaine ch2 = new Chaine(2,"TF2",103.99f,false);
        Récepteur lchaine = new Récepteur("TF");
        Récepteur lchaine2 = new Récepteur("TF2.2");
        lchaine.addChaine(ch);
        lchaine.addChaine(ch2);
        lchaine2.addChaine(ch);
        lchaine2.addChaine(ch2);
        lchaine.display();
        lchaine.printontextfile();
        lchaine2.printontextfile();

    }
}
