package Company;

/*public class B
{
    private int x;
    public B(int i){ x = i; }
    public Object clone()
    {
        try
        {
            return super.clone();
        }
        catch (CloneNotSupportedException e)
        {
            throw new InternalError(e.toString());
        }
    }
    public int getX() { return x; }
}
public class CloneTestB
{
    public static void main(String args[]) throws
            CloneNotSupportedException
    {
        B obj1 = new B(37);
        B obj2 = (B)obj1.clone();
        System.out.println(obj2.getX());
    }
}*/

/*question 1 : le code compile car il n'y a aucune erreur de synthax/compilation, en effet il y a bien une fonction clone() qui a été créé et lorsque le code compile
lorsque que le compilateur va chercher la fonction il va la trouver. Cependant lors de l'éxécution, le code fait appel à "super" or "super" est généralement la classe 
mère de cette classe B. Sauf que dans le cas du code si dessus la classe n'a pas de mère. Donc ça crée une erreur au moment de l'éxécution du code*/

/*question 3 : pour résoudre ce problème, il faut donc implémenter la classe vu en classe : Cloneable*/ 
