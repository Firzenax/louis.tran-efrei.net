package Chaine_TV;

public class TestRécepteur {
    Chaine ch1;
    Chaine ch2;
    Chaine ch3;
    Récepteur lchaine;

}
