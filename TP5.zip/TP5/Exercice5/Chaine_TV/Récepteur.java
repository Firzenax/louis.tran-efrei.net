package Chaine_TV;
import java.io.*;
import java.util.Vector;

public class Récepteur {
    private String nom;
    Vector<Chaine>vect;

    public Récepteur(String nom) {
        this.nom = nom;
        this.vect=new Vector<Chaine>();
    }

    public String getNom() {
        return nom;
    }

    public Vector<Chaine> getVect() {
        return vect;
    }

    public void addChaine(Chaine chaine) { this.vect.add(chaine); }
    public void removeChaine(Chaine chaine){this.vect.remove(this.vect.get(this.vect.indexOf(chaine)));}
    public void display() { for(int i =0;i< this.vect.size();i++) { System.out.println(this.vect.get(i)); } }

    @Override
    public String toString() {
        return "Récepteur{" +
                "nom='" + nom + '\'' +
                ", vect=" + vect +
                '}';
    }

    public void printontextfile()
    {
        PrintWriter output = null;
        try {
            output = new PrintWriter(new BufferedWriter(new FileWriter("Récepteur_"+this.nom+".txt", true)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        output.println(this.getVect());
        output.close();
    }

   /* public void loadtextfile(String name_file) throws IOException {
        BufferedReader in = null;
        try {
            in = new BufferedReader(new FileReader("Récepteur"+name_file+".txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        String line;
        while ((line = in.readLine()) != null)
        {
            // Afficher le contenu du fichier
            System.out.println (line);
        }
        in.close();
    }*/
}
