package Chaine_TV;

import java.util.Vector;

public class Chaine{
    private int numero;
    private String nom;
    private double Hz;
    private boolean popularite; // 0 pour  H et 1 pour V

    public Chaine(int numero, String nom, double hz, boolean popularite) {
        this.numero = numero;
        this.nom = nom;
        Hz = hz;
        this.popularite = popularite;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public double getHz() {
        return Hz;
    }

    public void setHz(double hz) {
        Hz = hz;
    }

    public boolean isPopularite() {
        return popularite;
    }

    public void setPopularite(boolean popularite) {
        this.popularite = popularite;
    }

    @Override
    public String toString() {
        return "Chaine{" +
                "numero=" + numero +
                ", nom='" + nom + '\'' +
                ", Hz=" + Hz +
                ", popularite=" + popularite +
                '}';
    }
}
